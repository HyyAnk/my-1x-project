# Source Projection Deduplication

Date: 2026-09-09. Main-direct, scoped allocation fix.

The context builder flattens eligibility projections for Episode and Reel, so one Bank question can appear twice in allocation input. Added per-slot ID deduplication before counting capacity. Four distinct questions projected twice must not fill an eight-question Episode slot.

Regression failed before fix and passed afterward. No provider or live Bank writes. Final suite evidence is recorded with the verified claim.
