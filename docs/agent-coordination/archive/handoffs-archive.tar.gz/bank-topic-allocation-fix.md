# Bank Topic Allocation Review Fix

- Date: 2026-09-09
- Working mode: main-direct; baseline c19612c2fc577b8950da6dda5373e88756c47837
- Scope: bankTopicAllocation.ts, topicCandidateValidator.ts, bankTopicGeneration.test.ts and this handoff
- Preserved concurrent product and storage work; no live data writes or provider calls

## Changes

Discovery allocation now requires a complete domain/subtopic group instead of filling from unrelated sources. Steered allocation requires all keyword tokens and a coherent group. Unknown provider slot IDs and surplus/missing response counts are rejected; new topic IDs are server-generated rather than provider-controlled.

## Evidence

Three regression cases failed before fixes: cross-domain grouping, partial keyword matches, unknown slot IDs. All 13 allocation/generation tests pass after fixes. Workspace typecheck passed; scoped ESLint passed. Full server results and zone checks are recorded in release evidence.

## Remaining Scope

Product, storage, and availability fixes are tracked by the coordinator separately. This handoff does not claim whole-upgrade acceptance.
