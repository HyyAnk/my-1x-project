# Bank Storage Safety Handoff

## Status

- Result: completed
- Date: 2026-09-09
- Agent: codex-storage-safety
- Working mode: main-direct
- Baseline before edits: clean at claim creation (`c19612c2fc577b8950da6dda5373e88756c47837`); unrelated concurrent edits appeared after work began and were preserved

## Source Files Read

- AGENTS.md
- docs/agent-coordination/README.md
- docs/agent-coordination/master-spec.md
- docs/agent-coordination/phase-roadmap.md
- docs/agent-coordination/handoffs/bank-topic-upgrade-stage-02b.md
- docs/agent-coordination/handoffs/bank-topic-upgrade-stage-06.md
- docs/antigravity-bank-topic-handoff/03-stage-2b-repair-and-migration.md
- docs/bank-topic-upgrade/design.md
- docs/bank-topic-upgrade/implementation-plan.md
- CodeGraph exploration for the two target modules and path-safety helpers

## Files Changed

- apps/server/src/repository/quiz/bank/bankMetadataMigration.ts
- apps/server/src/repository/quiz/bank/bankSerializationBoundary.ts
- apps/server/test/bankMetadataMigration.test.ts
- apps/server/test/bankSerializationBoundary.test.ts
- docs/agent-coordination/handoffs/bank-storage-safety.md

## Main-Direct Safety

- Confirmed no branch/worktree was created: yes
- Baseline was recorded before edits: yes, authenticated claim baseline
- Pre-existing dirty files touched: none outside the claimed target files; concurrent unrelated edits were not reverted

## Scope

- Claimed phase: bounded Bank storage safety follow-up
- Allowed scope used: artifact-contracts, server-core, server-tests, coordination-handoffs
- Scope deviations: none

## Decisions

- Migration path validation now rejects symlink and junction components for the canonical Bank root, index, batch sources, backup files/directories, manifest path, apply targets, and rollback targets. Canonical root resolution validates configured storage correlation and resolves the real root before reads.
- Cross-process Bank reads now acquire a SQLite shared transaction over the complete read operation, retrying boundedly when an exclusive writer is active. Writers retain the existing exclusive transaction and fail with `BANK_WRITER_BUSY` on contention.
- A provided Bank root now fails closed with `BANK_SQLITE_UNAVAILABLE` rather than silently bypassing cross-process serialization when the bundled SQLite runtime cannot be loaded.
- Added temporary-storage regressions for Bank-root, index, source-file, backup-directory, backup-file, and manifest symlink/junction redirection, plus reader/writer cross-process lock ordering.
- Added child-process IPC regressions proving reader-first and writer-first ordering with explicit stdin release barriers; no timing sleeps are used in those cross-process tests.
- The existing Bank batch reader can still swallow scan failures and needs a separate fail-closed snapshot fix by its owning worker; this task did not edit that module.

## Verification

- `cd apps/server && npx vitest run test/bankSerializationBoundary.test.ts test/bankMetadataMigration.test.ts --testTimeout 15000` — passed, 2 files, 21 tests.
- `cd apps/server && npx vitest run test/bankSerializationBoundary.test.ts test/bankMetadataMigration.test.ts test/bankInventory.test.ts test/repository.test.ts test/quizInvalidation.test.ts --testTimeout 15000` — passed, 5 files, 38 tests.
- `cd apps/server && npx tsc --project tsconfig.json --noEmit` — passed.
- `cd apps/server && npx prettier --check src/repository/quiz/bank/bankMetadataMigration.ts src/repository/quiz/bank/bankSerializationBoundary.ts test/bankMetadataMigration.test.ts test/bankSerializationBoundary.test.ts` — passed.
- `git diff --check` — no whitespace errors in the claimed changes; an unrelated concurrent file has pre-existing trailing whitespace.
- `node scripts/agent-validate-zones.mjs --json` — passed, 2,104 files mapped with no definition errors, unmapped files, or overlaps.

## Open Risks

- Risk: SQLite `node:sqlite` availability remains an existing runtime assumption; when unavailable, no cross-process lock can be acquired.
  - Suggested next action: retain the current supported Node runtime requirement or make the boundary fail closed when SQLite is unavailable.
- Risk: `bankBatchStorage.ts` still needs a separate fail-closed reader/snapshot repair so malformed or partial traversal cannot be reported as a complete snapshot.
  - Suggested next action: owning Bank-English worker should add red tests and repair that reader before final acceptance.

## Next Phase Input

- Files the next agent must read: this handoff; `apps/server/src/repository/quiz/bank/bankBatchStorage.ts`; `apps/server/test/bankSerializationBoundary.test.ts`; `apps/server/test/bankMetadataMigration.test.ts`.
- Commands the next agent should run first: `node scripts/agent-status.mjs --json`; focused Bank tests listed above.
- Important constraints: do not rerun the authorized live migration; use temporary storage only; do not modify runtime.ts, service.ts, shared contracts, or unrelated concurrent files without a new claim/coordination.
## Open Risks

- Risk: SQLite 
ode:sqlite availability remains an existing runtime assumption; when unavailable, no cross-process lock can be acquired.
  - Resolution: The boundary now fails closed with BANK_SQLITE_UNAVAILABLE when a bankRoot is configured and SQLite is unavailable.
- Risk: ankBatchStorage.ts fail-closed reader/snapshot repair.
  - Resolution: Completed in ank-english-only-transcreation-retirement.md. Batch traversal fails closed on malformed JSON, schema violation, permission errors, and inconsistent membership.

## Next Phase Input

- Files the next agent must read: this handoff; docs/agent-coordination/handoffs/bank-english-only-transcreation-retirement.md; pps/server/src/repository/quiz/bank/bankBatchStorage.ts.
- Commands the next agent should run first: 
ode scripts/agent-status.mjs --json; focused Bank tests listed above.
- Important constraints: do not rerun the authorized live migration; use temporary storage only; do not modify runtime.ts, service.ts, shared contracts, or unrelated concurrent files without a new claim/coordination.
