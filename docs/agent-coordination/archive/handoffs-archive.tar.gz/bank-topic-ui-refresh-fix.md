# Topic Availability Refresh Fix

- Date: 2026-09-09
- Scope: useTopicAvailability hook/tests, ChannelTopicsTab, this handoff
- Main-direct; preserved other claims and changes

## Behavior

Reset old availability when changing channel. Invalidate request sequence on cleanup and reject aborted results even if transport ignores abort. Do not launch internal polling when the parent already supplies availability.

## Evidence

Two new tests failed before fixes (old channel data visible; disabled hook accepted a late response). All eight hook tests pass after changes. Web suite and production web build passed. Remaining integration review and run metadata corrections are separate work; this is not overall acceptance.
