# Confirmation Repair Partial Handoff

## Status

- Result: partial, blocked by active bank-storage claim
- Date: 2026-09-09
- Agent: codex-confirmation-repair
- Working mode: main-direct
- Baseline before edits: 95 pre-existing dirty files captured at claim creation

## Scope and ownership

The active claim owns the independent thumbnail projection helper, selected server tests, and this handoff. The bank-storage agent owns the shared-contract, artifact, and server-core boundaries; confirmation routes, repositories, and product-localization implementation remain intentionally untouched until that claim releases.

## Changes in this partial phase

- `apps/server/src/quiz/thumbnail/thumbnailService.ts`
  - Loads Episode `localization.json` for thumbnail planning.
  - Uses localized description, thumbnail hook text, and quiz display projections when the artifact is applied.
  - Maps the source answer to the corresponding localized choice by index, preserving the canonical English source.
- `apps/server/test/shortReelLocalization.test.ts`
  - Added red reproductions for corrupt Short-Reel and Episode localization artifacts (loaders currently resolve `null` instead of failing closed).
  - Added a green regression test for localized thumbnail answer projection.

## Verification and red evidence

- `pnpm --filter @studio/server exec tsc --noEmit --pretty false`: passed.
- Focused localization tests excluding the two intentional corrupt-artifact reproductions: 7 passed, 3 skipped.
- Red reproduction command: `pnpm --filter @studio/server test -- test/shortReelLocalization.test.ts -t "fails closed"`.
  - 2 failures, both expected: corrupt Short-Reel and Episode localization loaders resolved `null` rather than rejecting with `LOCALIZATION_CORRUPTED`.
- Red thumbnail projection reproduction was verified before the index-based fix: the localized choice text changed but the answer remained the English source answer.

## Required follow-up after bank claim release

- Expand into `shared-contracts`, `artifact-contracts`, `server-core`, `api-contracts`, and `short-reel-application` with concrete confirmation and localization files.
- Add `target_language` to Episode HTTP input and validate unsupported languages before provider work.
- Replace unconditional Short-Reel concurrent join with normalized-option conflict handling.
- Implement preparing/completed receipts with reserved identity and idempotent recovery across localization, receipt, history, projection, and publish failures.
- Make localization artifact loaders fail closed with `LOCALIZATION_CORRUPTED` while preserving `ENOENT` as absence.
- Add channel-language invalidation/relocalization for localization-dependent Reel artifacts while preserving English snapshots and user content.
- Do not edit `apps/server/src/repository/topics.ts` unless an explicit claim expansion resolves the authoritative binding dependency.
