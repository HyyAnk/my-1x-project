﻿# Bank English-Only Write Enforcement and Transcreation Retirement Handoff

## Status

- Result: completed
- Date: 2026-09-09
- Agent: antigravity-bank-storage
- Working mode: main-direct
- Baseline before edits: dirty baseline preserved; claim id claim-antigravitybankstorage-mtte1rno

## Source Files Read

- AGENTS.md
- GEMINI.md
- docs/agent-coordination/README.md
- docs/agent-coordination/master-spec.md
- docs/agent-coordination/phase-roadmap.md
- docs/antigravity-bank-topic-resume/README.md
- docs/antigravity-bank-topic-resume/01-status-and-recovery.md
- docs/antigravity-bank-topic-resume/02-bank-storage.md
- docs/antigravity-bank-topic-resume/prompts/01-bank.md
- docs/agent-coordination/handoffs/bank-storage-safety.md

## Files Changed

- apps/server/src/repository/quiz/bank/bankWritePolicy.ts
- apps/server/src/repository/quiz/bank/bankBatchStorage.ts
- apps/server/src/repository/quiz/bank/bankMutationEngine.ts
- apps/server/src/repository/quiz/bank/bankTranslationStore.ts
- apps/server/src/repository/quiz/bank/bankSerializationBoundary.ts
- apps/server/src/repository/quiz/bank/bankQueryEngine.ts
- apps/server/src/routes/questionBank/buildRoutes.ts
- apps/server/src/routes/questionBank/crudRoutes.ts
- apps/server/test/questionBankEnglishOnly.test.ts
- apps/server/test/questionBankRepository.test.ts
- apps/server/test/questionBankIntegration.test.ts
- apps/server/test/questionBankRoute.test.ts
- apps/server/test/bankSerializationBoundary.test.ts
- docs/agent-coordination/handoffs/bank-english-only-transcreation-retirement.md
- docs/agent-coordination/handoffs/bank-storage-safety.md

## Main-Direct Safety

- Confirmed no branch/worktree was created: yes
- Baseline was recorded before edits: yes
- Pre-existing dirty files touched: only planned files within active claim write zones; unrelated dirty files untouched

## Scope

- Claimed zones: artifact-contracts, api-contracts, server-tests, coordination-handoffs
- Read stable: shared-contracts
- Scope deviations: none

## Key Implementations & Decisions

1. Explicit English Metadata Policy:
   - Single and batch question bank write methods enforce explicit language === 'en'. Missing, undefined, or non-English languages are strictly rejected with BANK_ENGLISH_ONLY.
   - Any attempt to persist non-empty translations to the Question Bank is rejected with typed error BANK_TRANSLATION_WRITES_RETIRED.
   - UI forms and REST endpoints emit and require explicit English language metadata.

2. Transcreation Endpoint Retirement:
   - Direct HTTP route /api/question-bank/:id/transcreate returns HTTP 410 Gone with error code BANK_TRANSCREATION_RETIRED immediately before any repository lookup, provider invocation, or filesystem mutation.
   - saveQuestionBankTranslationUnlocked and saveQuestionBankTranslation reject with BANK_TRANSLATION_WRITES_RETIRED.

3. Fail-Closed Batch Traversal:
   - listQuestionBankBatchesUnlocked and readSubtopicBatchUnlocked now fail closed on malformed JSON, schema parsing errors, permission errors, and inconsistent membership (mismatched subtopic ID, domain ID, or archetype ID).
   - Only a truly absent directory (ENOENT) yields empty results. Any corrupted file causes an immediate typed error (BANK_BATCH_CORRUPT, BANK_BATCH_INCONSISTENT, BANK_READ_FAILED).

4. 10,000-Record Ceiling Removal for Single Lookups:
   - getQuestionBankQuestionUnlocked now resolves directly from complete batch scans and performs single-question cooldown calculation, eliminating the 10,000-record query limit.

5. Cross-Process Serialization & Child Test Hardening:
   - openReaderLock executes CREATE TABLE IF NOT EXISTS lock_lease ... BEGIN; SELECT count(*) FROM lock_lease; inside its transaction to acquire shared read locks reading actual database pages.
   - Child process tests in bankSerializationBoundary.test.ts attach all IPC stream listeners immediately upon spawn with buffering and order-aware child startup, completely eliminating the previous vitest timeout.

## Verification

- pnpm --filter @studio/server test -- test/questionBankRepository.test.ts test/questionBankIntegration.test.ts test/questionBankRoute.test.ts test/questionBankTranscreation.test.ts test/bankSerializationBoundary.test.ts test/bankMetadataMigration.test.ts test/questionBankEnglishOnly.test.ts: Passed (7 files, 80 tests).
- pnpm typecheck: Passed cleanly across all workspace packages.
- node scripts/agent-validate-zones.mjs --json: Passed (2,124 files mapped, 0 errors, 0 unmapped, 0 overlapping).

## Open Risks

- None remaining for Work 1. All Bank storage safety and transcreation retirement requirements are fully verified.

## Next Phase Input

- Proceed to Work 2: Episode confirmation and localization (docs/antigravity-bank-topic-resume/03-episode-confirmation.md).
